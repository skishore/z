designer: Khaled Hosny
url: http://amirifont.org
license: OFL
description: Amiri is a classical Arabic typeface in Naskh style for
typesetting books and other running text. Its design is a revival of the
beautiful typeface pioneered in early 20th century by Bulaq Press in Cairo,
also known as Amiria Press, after which the font is named.

