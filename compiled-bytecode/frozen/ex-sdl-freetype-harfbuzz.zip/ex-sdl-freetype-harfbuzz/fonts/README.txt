The fonts in this directory come from various places. For font licensing information
please check with the specific font vendors (they are all rather open and amiable, but
please review any licenses before you rip the font files from here and embed them in
your application).

DejaVuSerif.ttf: http://dejavu-fonts.org/
lateef.ttf     : http://scripts.sil.org/cms/scripts/page.php?item_id=ArabicFonts_Download#ofl
fireflysung.ttf: fonts/fireflysung-1.3.0/COPYRIGHT
