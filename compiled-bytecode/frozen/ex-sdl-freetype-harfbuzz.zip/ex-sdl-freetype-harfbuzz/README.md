This is a simplish sample application to get from zero to rendering unicode
text using harfbuzz to do the text layout, freetype for the underlying font
magic, some trivial code for the anti-aliased font rasterization, and the SDL 
to create the window to display stuff in.

Based on and forked from https://github.com/anoek/ex-sdl-cairo-freetype-harfbuzz/

Many thanks.

Screenshot
==========

![Screenshot](https://github.com/lxnt/ex-sdl-freetype-harfbuzz/raw/master/screenshot.png)
